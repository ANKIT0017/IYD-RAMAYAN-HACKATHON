ankit->1,2
krishna->3,4
rahul->5,6